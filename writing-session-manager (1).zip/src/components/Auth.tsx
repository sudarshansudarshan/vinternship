import React, { useState } from 'react';
import { storage, User } from '../lib/storage';
import { toast } from 'sonner';
import { LogIn, LogOut, FileText, Mail, User as UserIcon, ArrowRight, Loader2, Ghost } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Auth({ user, onAuthChange }: { user: User | null, onAuthChange: () => void }) {
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'options' | 'email' | 'signup'>('options');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    setLoading(true);
    
    // Mock authentication
    setTimeout(() => {
      const newUser: User = {
        uid: crypto.randomUUID(),
        email: email,
        displayName: email.split('@')[0],
        isAnonymous: false
      };
      storage.setUser(newUser);
      toast.success(mode === 'signup' ? 'Account created successfully!' : 'Signed in successfully!');
      setLoading(false);
      onAuthChange();
    }, 1000);
  };

  const handleGuestSignIn = async () => {
    setLoading(true);
    setTimeout(() => {
      const newUser: User = {
        uid: 'guest-' + crypto.randomUUID(),
        email: 'guest@writing.local',
        displayName: 'Guest Writer',
        isAnonymous: true
      };
      storage.setUser(newUser);
      toast.success('Continuing as Guest...');
      setLoading(false);
      onAuthChange();
    }, 800);
  };

  if (user) return null;

  return (
    <div className="w-full max-w-md p-8 bg-white rounded-3xl shadow-sm border border-gray-100">
      <div className="flex flex-col items-center mb-8">
        <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-blue-500/20">
          <FileText className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Writing Manager</h2>
        <p className="text-gray-500 text-center text-sm mt-2">
          Sign in to save your writing sessions
        </p>
      </div>

      <AnimatePresence mode="wait">
        {mode === 'options' ? (
          <motion.div
            key="options"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-4"
          >
            <button
              onClick={() => setMode('email')}
              className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-blue-500 text-white rounded-2xl font-bold hover:bg-blue-600 transition-all shadow-lg shadow-blue-500/20"
            >
              <Mail className="w-5 h-5" />
              Sign in with Email
            </button>

            <button
              onClick={handleGuestSignIn}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-gray-50 text-gray-700 rounded-2xl font-bold hover:bg-gray-100 transition-all"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Ghost className="w-5 h-5" />}
              Continue as Guest
            </button>

            <div className="relative py-4">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-100"></div></div>
              <div className="relative flex justify-center text-xs font-bold text-gray-300 bg-white px-4 uppercase tracking-widest">New Writer?</div>
            </div>

            <button
              onClick={() => setMode('signup')}
              className="w-full py-4 text-sm font-bold text-blue-500 hover:text-blue-600 transition-colors"
            >
              Create an account
            </button>
          </motion.div>
        ) : (
          <motion.form
            key="email"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            onSubmit={handleEmailAuth}
            className="space-y-4"
          >
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 ml-1 uppercase tracking-widest">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-6 py-4 bg-gray-50 rounded-2xl border border-transparent focus:border-blue-500 focus:bg-white outline-none transition-all"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 ml-1 uppercase tracking-widest">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-6 py-4 bg-gray-50 rounded-2xl border border-transparent focus:border-blue-500 focus:bg-white outline-none transition-all"
                required
              />
            </div>
            
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-blue-500 text-white rounded-2xl font-bold hover:bg-blue-600 transition-all disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowRight className="w-5 h-5" />}
              {mode === 'signup' ? 'Create Account' : 'Sign In'}
            </button>

            <button
              type="button"
              onClick={() => setMode('options')}
              className="w-full text-sm font-bold text-gray-400 hover:text-gray-600 transition-colors"
            >
              Back to options
            </button>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  );
}
