import React, { useState, useEffect } from 'react';
import { storage, WritingSession, User } from '../lib/storage';
import { Save, Trash2, Clock, FileText, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';

export default function WritingArea({ user }: { user: User }) {
  const [text, setText] = useState('');
  const [isPasted, setIsPasted] = useState(false);
  const [sessions, setSessions] = useState<WritingSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);

  useEffect(() => {
    const loadedSessions = storage.getSessions(user.uid);
    setSessions(loadedSessions);
  }, [user.uid]);

  const handleSave = () => {
    if (!text.trim()) {
      toast.error('Cannot save an empty session');
      return;
    }

    const session: WritingSession = {
      id: crypto.randomUUID(),
      userId: user.uid,
      text: text,
      isPasted: isPasted,
      createdAt: new Date().toISOString()
    };

    storage.saveSession(session);
    setSessions([session, ...sessions]);
    setText('');
    setIsPasted(false);
    toast.success('Session saved successfully!');
  };

  const deleteSession = (id: string) => {
    storage.deleteSession(id);
    setSessions(sessions.filter(s => s.id !== id));
    toast.error('Session deleted');
  };

  return (
    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-8">
      {/* Editor Section */}
      <div className="lg:col-span-3 space-y-6">
        <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-50 flex items-center justify-between bg-gray-50/50">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-500" />
              <span className="text-sm font-bold text-gray-700 uppercase tracking-widest">New Writing Session</span>
            </div>
            <div className="text-xs text-gray-400 font-mono">
              {text.length} characters
            </div>
          </div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            onPaste={() => setIsPasted(true)}
            placeholder="Start writing your thoughts here..."
            className="w-full h-[60vh] p-12 outline-none resize-none text-xl leading-relaxed font-serif placeholder:text-gray-200"
          />
          <div className="p-6 border-t border-gray-50 flex justify-end bg-gray-50/50">
            <button
              onClick={handleSave}
              disabled={!text.trim()}
              className="flex items-center gap-2 px-8 py-4 bg-blue-500 text-white rounded-2xl font-bold hover:bg-blue-600 transition-all shadow-lg shadow-blue-500/20 disabled:opacity-50 disabled:shadow-none"
            >
              <Save className="w-5 h-5" />
              Save Session
            </button>
          </div>
        </div>
      </div>

      {/* Sidebar Section */}
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">Saved Sessions</h3>
            <Clock className="w-4 h-4 text-gray-300" />
          </div>
          
          <div className="space-y-3 max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
            <AnimatePresence mode="popLayout">
              {sessions.map((session) => (
                <motion.div
                  key={session.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="group p-4 bg-gray-50 rounded-2xl border border-transparent hover:border-blue-100 hover:bg-white transition-all cursor-pointer relative"
                  onClick={() => setText(session.text)}
                >
                  <div className="flex flex-col gap-1 pr-8">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-400">
                        {new Date(session.createdAt).toLocaleDateString()}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-tighter ${session.isPasted ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'}`}>
                        {session.isPasted ? 'Pasted' : 'Typed'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 line-clamp-2 font-serif italic">
                      {session.text}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteSession(session.id);
                    }}
                    className="absolute top-4 right-4 p-1 text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>

            {sessions.length === 0 && (
              <div className="text-center py-12 opacity-40">
                <Plus className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p className="text-[10px] font-bold uppercase tracking-widest">No sessions yet</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
