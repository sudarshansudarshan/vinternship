import React, { useState, useEffect } from 'react';
import { storage, User } from './lib/storage';
import { Toaster } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, LogOut } from 'lucide-react';
import Auth from './components/Auth';
import WritingArea from './components/WritingArea';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedUser = storage.getUser();
    setUser(storedUser);
    setLoading(false);
  }, []);

  const handleAuthChange = () => {
    const storedUser = storage.getUser();
    setUser(storedUser);
  };

  const handleSignOut = () => {
    storage.setUser(null);
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans selection:bg-blue-100">
      <Toaster position="top-center" richColors />
      
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-xl border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight">Writing Session Manager</h1>
          </div>

          {user && (
            <div className="flex items-center gap-4">
              <div className="flex flex-col items-end">
                <span className="text-sm font-bold">{user.displayName}</span>
                <span className="text-xs text-gray-400">{user.email}</span>
              </div>
              <button 
                onClick={handleSignOut}
                className="p-2 hover:bg-red-50 rounded-full transition-colors group"
                title="Sign Out"
              >
                <LogOut className="w-5 h-5 text-gray-400 group-hover:text-red-500" />
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {!user ? (
            <motion.div
              key="auth"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex justify-center"
            >
              <Auth user={user} onAuthChange={handleAuthChange} />
            </motion.div>
          ) : (
            <motion.div
              key="writing-area"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <WritingArea user={user} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-gray-100 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <FileText className="w-5 h-5 text-gray-200" />
          <span className="text-xs font-bold uppercase tracking-widest text-gray-300">Writing Session Manager v1.0</span>
        </div>
      </footer>
    </div>
  );
}
