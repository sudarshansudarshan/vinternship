export interface WritingSession {
  id: string;
  userId: string;
  text: string;
  isPasted: boolean;
  createdAt: string;
}

export interface User {
  uid: string;
  email: string;
  displayName: string;
  isAnonymous: boolean;
}

const SESSIONS_KEY = 'writing_sessions';
const USER_KEY = 'writing_user';

export const storage = {
  getSessions: (userId: string): WritingSession[] => {
    const data = localStorage.getItem(SESSIONS_KEY);
    if (!data) return [];
    try {
      const allSessions: WritingSession[] = JSON.parse(data);
      return allSessions.filter(s => s.userId === userId).sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } catch (e) {
      return [];
    }
  },

  saveSession: (session: WritingSession) => {
    const data = localStorage.getItem(SESSIONS_KEY);
    const allSessions: WritingSession[] = data ? JSON.parse(data) : [];
    allSessions.push(session);
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(allSessions));
  },

  deleteSession: (sessionId: string) => {
    const data = localStorage.getItem(SESSIONS_KEY);
    if (!data) return;
    try {
      const allSessions: WritingSession[] = JSON.parse(data);
      const filtered = allSessions.filter(s => s.id !== sessionId);
      localStorage.setItem(SESSIONS_KEY, JSON.stringify(filtered));
    } catch (e) {
      // Ignore
    }
  },

  getUser: (): User | null => {
    const data = localStorage.getItem(USER_KEY);
    if (!data) return null;
    try {
      return JSON.parse(data);
    } catch (e) {
      return null;
    }
  },

  setUser: (user: User | null) => {
    if (user) {
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(USER_KEY);
    }
  }
};
